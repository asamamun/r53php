

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Image Upload</title>

    <!-- bootstrap css  -->
    <!-- <link rel="stylesheet" href="	https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css"> -->
  <link rel="stylesheet" href="assets/css/bootstrap.min.css">
    <style>
       .output img{
        width: 150px;
        margin: 20px 30px;

       }
       form{
        width: 600px;
        margin: 50px auto;
        padding: 30px;
        border-radius: 15px;
        box-shadow: 5px 5px 10px #000;
       }
    </style>
</head>
<body>


<?php 
   
 if(isset($_POST['upload'])){

  $image1 = $_FILES["image1"];
   $image2 = $_FILES["image2"];
   $image3 = $_FILES["image3"];

 
    $todir = 'images/';

$im;
$im2;
$im3;

    $allowed = array("image/jpeg","image/jpg", "image/gif", "image/png",'image/webp');

    // image 1 upload
    if(in_array($image1['type'],$allowed)){
        move_uploaded_file($image1["tmp_name"],$todir."banner1.jpg");

        $im = true;
      
      }else{
        $im = false;
      }

    // image 2 upload
    if(in_array($image2['type'],$allowed)){
        move_uploaded_file($image2["tmp_name"],$todir."banner2.jpg");
        $im2 = true;
      
      }else{
        $im2 = false;
      }
    // image 3 upload
    if(in_array($image3['type'],$allowed)){
        move_uploaded_file($image3["tmp_name"],$todir."banner3.jpg");
        $im3 = true;
      
      }else{
        $im3 = false;
      }
if($im && $im2 && $im3){
  header("Location: banner.php");

}
  
    
 }

?>

<!-- upload form area start  -->
<div class="container mt-5">
    <form action="" method="post" enctype="multipart/form-data" >
      <h2 class="text-center">Upload Image</h2>
      <hr>
        <div id="output" class="output">
        
        </div>
        <div class="mb-3">
            <label for="formFile" class="form-label">Upload Image 1</label>
            
            <input class="form-control" name="image1" type="file" id="formFile" onchange="preview_image(event)">
        </div>
        <div class="mb-3">
            <label for="formFile" class="form-label">Upload Image 2</label>
          
            <input class="form-control" name="image2" type="file" id="formFile" onchange="preview_image(event)">
        </div>
        <div class="mb-3">
            <label for="formFile" class="form-label">Upload Image 3</label>
        
            <input onchange="preview_image(event)" class="form-control" name="image3" type="file" id="formFile">
        </div>
        <input class="btn btn-outline-primary" type="submit" name="upload" value="Upload">
    </form>
</div>
<!-- upload form area end  -->



<!-- bootstrap js      -->
<!-- <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/js/bootstrap.bundle.min.js"></script> -->
<script src="assets/js/bootstrap.bundle.min.js"></script>
<script>
  let res = [];
function preview_image(event) 
  {
  var reader = new FileReader();

  reader.onload = function()
  {
    var output = document.getElementById('output');

    // for (let i = 0; i < reader.length; i++) {
    //     output.innerHTML += `<img src="${reader[i].result}">`;
        
    // }
  }


res.push(event.target.files[0]);



 for (let i = 0; i < res.length; i++) {

  reader.readAsDataURL(res[i]);
    
 }

 


  }


</script>
</body>
</html>