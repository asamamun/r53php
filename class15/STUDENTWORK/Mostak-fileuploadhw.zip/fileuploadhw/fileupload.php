<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>File Upload</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-GLhlTQ8iRABdZLl6O3oVMWSktQOp6b7In1Zl3/Jr59b6EGGoI1aFkw7cmDA6j6gD" crossorigin="anonymous">
    <link rel="stylesheet" href="css/bootstrap.min.css">
<style>
    .col-6{
        border:1px solid black;
        border-radius:15px;
        padding:15px;
        box-shadow: 8px 10px 10px green;
        color:red;
    }
    .col-6 h1{
        text-align:center;
    }
</style>
</head>
<?php 
if(isset($_POST['upload'])){
 $img1 = $_FILES['im1'];
 $img2 = $_FILES['im2'];
 $img3 = $_FILES['im3'];
  
//  foreach($img1 as $k1 => $val1 ){
//     echo "$k1 :$val1 <br/>";
//  }

 $allowed = array("image/jpeg", "image/gif", "image/png",'image/webp');
//for img 1 
 if(in_array($img1['type'],$allowed)){
    move_uploaded_file($img1['tmp_name'],"banner1.jpg");
 }
//for img 2
if(in_array($img2['type'],$allowed)){
    move_uploaded_file($img2['tmp_name'],"banner2.jpg");
}
//for img 3
if(in_array($img3['type'],$allowed)){
move_uploaded_file($img3['tmp_name'],"banner3.jpg");
}

}

?>
<body>

    <div class="container row"><h1></h1><br><br><br>
    <div class="col-6 mx-auto">

            <h1 class="mx-auto text-align-center">File Upload Demo</h1><br>
            <a href="carosule.php">See Image</a>
            <br><br>

            <form action="" method="post" enctype="multipart/form-data">
                <div class="mb-3">
                    <label for="formFile" class="form-label">Input Image 01</label>
                    <input class="form-control" type="file" id="formFile" name="im1">
                </div>
                <div class="mb-3">
                    <label for="formFile" class="form-label">Input Image 02</label>
                    <input class="form-control" type="file" id="formFile" name="im2">
                </div>
                <div class="mb-3">
                    <label for="formFile" class="form-label">Input Image 03</label>
                    <input class="form-control" type="file" id="formFile" name="im3">
                </div>
                <div class="mb-3">
                    
                    <input class="form-control" type="submit" id="" name="upload" value="Upload File">
                </div>
            </form>
        </div>







        

    </div>






<script src="js/bootstrap.min.js"></script>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/js/bootstrap.bundle.min.js" integrity="sha384-w76AqPfDkMBDXo30jS1Sgez6pr3x5MlQ1ZAGC+nuZB+EYdgRZgiwxhTBTkF7CXvN" crossorigin="anonymous"></script>
</body>

</html>