<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>File Upload</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-GLhlTQ8iRABdZLl6O3oVMWSktQOp6b7In1Zl3/Jr59b6EGGoI1aFkw7cmDA6j6gD" crossorigin="anonymous">
    <link rel="stylesheet" href="css/bootstrap.min.css">
    <style>
    .col-6{
        border:1px solid black;
        border-radius:15px;
        padding:15px;
        box-shadow: 8px 10px 10px gray;
        color:green;
    }
    .col-6 h1{
        text-align:center;
    }
</style>
</head>

<body>

    <div class="container row">
        
    <h1></h1>
    <br><br><br>
        


<h1></h1>




        <div id="carouselExample" class="carousel slide mt-5 col-6 mx-auto">
            <h1>Picture Upload By Admin</h1>
            <!-- <a href="fileupload.php">Upload Image</a><br> -->
            <div class="carousel-inner">
                <div class="carousel-item active">
                    <img src="banner1.jpg?<?=rand(1,999) ?>" class="d-block w-100" alt="...">
                </div>
                <div class="carousel-item">
                    <img src="banner2.jpg?<?=rand(1,999) ?>" class="d-block w-100" alt="...">
                </div>
                <div class="carousel-item">
                    <img src="banner3.jpg?<?=rand(1,999) ?>" class="d-block w-100" alt="...">
                </div>
            </div>
            <button class="carousel-control-prev" type="button" data-bs-target="#carouselExample" data-bs-slide="prev">
                <span class="carousel-control-prev-icon" aria-hidden="true"></span>
                <span class="visually-hidden">Previous</span>
            </button>
            <button class="carousel-control-next btn-outline-primary" type="button" data-bs-target="#carouselExample" data-bs-slide="next">
                <span class="carousel-control-next-icon" aria-hidden="true"></span>
                <span class="visually-hidden">Next</span>
            </button>
        </div>

    </div>






<script src="js/bootstrap.min.js"></script>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/js/bootstrap.bundle.min.js" integrity="sha384-w76AqPfDkMBDXo30jS1Sgez6pr3x5MlQ1ZAGC+nuZB+EYdgRZgiwxhTBTkF7CXvN" crossorigin="anonymous"></script>
</body>

</html>