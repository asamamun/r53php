<?php
if(isset($_POST['sub'])){
    $f = $_FILES['img'];
    
    $type =$f['type'];
    $tmp_name=$f['tmp_name'];
    $name = $f['name'];
    $size = $f['size'];

    move_uploaded_file($tmp_name, "img/".$name);
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    <form action="#" method="post" enctype="multipart/form-data">
    <input type="file" name="img">
    <br><br>
    <input type="submit" name="sub" value="upload">
    </form>
</body>
</html>