<?php
if(isset($_POST["btnsubmit"])){
    $file=$_FILES["image"];

    $tmp_name= $file["tmp_name"];
    $name= $file["name"];
    
    $size= $file["size"];
    $type= $file["type"];

    
    move_uploaded_file($tmp_name, "img/$name");
    
    
   echo "<img src='img/$name' width='100px'>";
    

}
?>
<form action="#" method="post" enctype="multipart/form-data">
    <label for="">image</label><br>
    <input type="file" name="image">
    <input name="btnsubmit" type="submit" >
</form>


